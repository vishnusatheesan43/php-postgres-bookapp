<div class="form-card">
    <a class="muted" href="index.php">← Back to catalog</a>
    <h2><?= $id ? 'Edit Book' : 'Add New Book' ?></h2>
    <p class="muted"><?= $id ? 'Update the details of this book.' : 'Add a new book to your catalog.' ?></p>
    <form method="POST">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf']) ?>">
        <div class="field">
            <label for="title">Book Title</label>
            <input id="title" type="text" name="title" value="<?= htmlspecialchars($book['title'] ?? '') ?>" placeholder="e.g. Kubernetes Patterns" required>
        </div>
        <div class="field">
            <label for="author">Author</label>
            <input id="author" type="text" name="author" value="<?= htmlspecialchars($book['author'] ?? '') ?>" placeholder="e.g. Bilgin Ibryam" required>
        </div>
        <div class="field">
            <label for="year">Publication Year</label>
            <input id="year" type="number" name="year" value="<?= htmlspecialchars($book['year'] ?? date('Y')) ?>" min="1000" max="<?= date('Y') ?>" required>
        </div>
        <div class="form-actions">
            <button class="btn btn-primary" type="submit"><?= $id ? '✓ Update Book' : '＋ Add Book' ?></button>
            <a class="btn btn-secondary" href="index.php">Cancel</a>
        </div>
    </form>
</div>